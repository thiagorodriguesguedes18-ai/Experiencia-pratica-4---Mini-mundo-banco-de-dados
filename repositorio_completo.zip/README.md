# Projeto da Atividade — Nota 10 Garantida

Este repositório contém toda a estrutura necessária para entregar o trabalho exatamente como pede a atividade.

## Conteúdo
- `documentacao/atividade.pdf` — Documento final da atividade (versão entregue).
- `codigo/sql/` — Scripts SQL solicitados.
- `codigo/modelagem/` — Modelo conceitual, lógico e físico.
- `apresentacao/` — Slides e materiais visuais.
- `relatorio/` — Arquivos organizados usados para montar o PDF final.

## Autor
Thiago Guedes — GitHub: @ThiagoGuedes27 / @thiagorodriguesguedes18-ai
