
-- Funcionários ordenados por salário
SELECT nome, salario FROM funcionario ORDER BY salario DESC;

-- Funcionários do departamento de TI
SELECT f.nome, d.nome AS departamento
FROM funcionario f
JOIN departamento d ON f.id_departamento = d.id_departamento
WHERE d.nome = 'TI';

-- Buscar funcionários com salário acima de 5000
SELECT * FROM funcionario WHERE salario > 5000;

-- Limitar resultados
SELECT nome FROM funcionario LIMIT 3;

-- Exibir média salarial por departamento
SELECT d.nome, AVG(f.salario) AS media_salarial
FROM funcionario f
JOIN departamento d ON f.id_departamento = d.id_departamento
GROUP BY d.nome;
