# Projeto SQL – Mini-mundo Completo

Este repositório contém todos os scripts SQL exigidos na atividade:
- Script de criação das tabelas (DDL)
- Script de inserts (DML)
- Script de consultas SELECT
- Script com UPDATE e DELETE
- Instruções de execução

## Como executar
1. Abra MySQL Workbench (ou outro SGBD compatível).
2. Execute `01_ddl.sql`.
3. Execute `02_inserts.sql`.
4. Utilize `03_selects.sql` para consultas.
5. Use `04_updates_deletes.sql` para manipulação de dados.

Pronto para avaliação.  
