
-- UPDATES
UPDATE funcionario SET salario = salario * 1.10 WHERE id_funcionario = 1;
UPDATE funcionario SET email = 'ana.torres@empresa.com' WHERE nome = 'Ana Torres';
UPDATE funcionario SET id_departamento = 1 WHERE nome = 'Pedro Rocha';

-- DELETES
DELETE FROM funcionario WHERE salario < 4000;
DELETE FROM funcionario WHERE nome = 'Carlos Lima';
DELETE FROM departamento WHERE nome = 'Marketing';
