
INSERT INTO departamento (nome) VALUES
('Financeiro'), ('RH'), ('TI'), ('Marketing');

INSERT INTO funcionario (nome, email, salario, id_departamento) VALUES
('João Silva','joao@empresa.com',4500,1),
('Maria Souza','maria@empresa.com',5200,3),
('Carlos Lima','carlos@empresa.com',3900,2),
('Ana Torres','ana@empresa.com',6100,3),
('Pedro Rocha','pedro@empresa.com',4300,4);
